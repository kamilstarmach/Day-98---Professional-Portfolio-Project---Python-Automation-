"""FlowPilot — a safe, configurable file automation toolkit."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = "1.0.0"
DEFAULT_RULES = {
    "documents": [".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".md"],
    "spreadsheets": [".csv", ".xls", ".xlsx", ".ods"],
    "images": [".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp"],
    "audio": [".mp3", ".wav", ".flac", ".m4a", ".ogg"],
    "video": [".mp4", ".mov", ".mkv", ".avi", ".webm"],
    "archives": [".zip", ".tar", ".gz", ".7z", ".rar"],
    "code": [".py", ".js", ".ts", ".html", ".css", ".java", ".cpp", ".json", ".yaml", ".yml"],
}


def load_rules(path: Path | None = None) -> dict[str, list[str]]:
    """Load extension rules from JSON or return defaults."""
    if path is None:
        return {key: list(value) for key, value in DEFAULT_RULES.items()}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("Rules file must contain a JSON object.")
        rules = {}
        for category, extensions in data.items():
            if not isinstance(category, str) or not isinstance(extensions, list):
                raise ValueError("Each rule must map a category name to a list of extensions.")
            rules[category] = [
                ext.lower() if ext.startswith(".") else "." + ext.lower()
                for ext in extensions if isinstance(ext, str) and ext.strip()
            ]
        return rules
    except OSError as exc:
        raise ValueError(f"Cannot read rules file: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid rules JSON: {exc}") from exc


def category_for(path: Path, rules: dict[str, list[str]]) -> str:
    suffix = path.suffix.lower()
    for category, extensions in rules.items():
        if suffix in extensions:
            return category
    return "other"


def unique_destination(destination: Path) -> Path:
    """Return a non-existing path by appending a numbered suffix if needed."""
    if not destination.exists():
        return destination
    parent, stem, suffix = destination.parent, destination.stem, destination.suffix
    counter = 1
    while True:
        candidate = parent / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            return candidate
        counter += 1


def plan_organization(source: Path, destination: Path, rules: dict[str, list[str]]) -> list[dict[str, str]]:
    """Build a preview plan without changing any files."""
    source = source.expanduser().resolve()
    destination = destination.expanduser().resolve()
    if not source.exists() or not source.is_dir():
        raise ValueError(f"Source directory does not exist: {source}")
    if source == destination or source in destination.parents:
        raise ValueError("Destination must not be the source directory or inside it.")

    plan = []
    for item in sorted(source.iterdir(), key=lambda p: p.name.lower()):
        if not item.is_file():
            continue
        category = category_for(item, rules)
        target_dir = destination / category
        target = unique_destination(target_dir / item.name)
        # Reserve the planned target name so two same-name items cannot collide.
        plan.append({"source": str(item), "destination": str(target), "category": category})
    return plan


def apply_organization(plan: list[dict[str, str]], destination: Path) -> list[dict[str, str]]:
    """Move files according to a plan; never overwrite an existing file."""
    destination.mkdir(parents=True, exist_ok=True)
    results = []
    for entry in plan:
        source = Path(entry["source"])
        target = Path(entry["destination"])
        target.parent.mkdir(parents=True, exist_ok=True)
        # Re-check at execution time in case a destination appeared after preview.
        target = unique_destination(target)
        shutil.move(str(source), str(target))
        results.append({**entry, "destination": str(target), "result": "moved"})
    return results


def write_report(results: list[dict[str, str]], path: Path) -> None:
    """Write a timestamped JSON report."""
    report = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "version": VERSION,
        "files_processed": len(results),
        "results": results,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


def print_plan(plan: list[dict[str, str]]) -> None:
    if not plan:
        print("No files found to organize.")
        return
    print(f"Preview: {len(plan)} file(s) would be moved\n")
    for entry in plan:
        print(f"[{entry['category']}] {Path(entry['source']).name} -> {entry['destination']}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="FlowPilot — preview and automate file organization safely."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    organize = subparsers.add_parser("organize", help="Organize files into category folders")
    organize.add_argument("source", type=Path, help="Directory containing files")
    organize.add_argument("destination", type=Path, help="Directory for organized files")
    organize.add_argument("--rules", type=Path, help="Optional JSON extension-rules file")
    organize.add_argument("--apply", action="store_true", help="Actually move files (default is preview)")
    organize.add_argument("--report", type=Path, help="Write a JSON report")

    rules = subparsers.add_parser("show-rules", help="Print the built-in extension rules")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "show-rules":
        print(json.dumps(DEFAULT_RULES, indent=2))
        return 0
    try:
        rules = load_rules(args.rules)
        plan = plan_organization(args.source, args.destination, rules)
        print_plan(plan)
        if not args.apply:
            print("\nPreview only. Add --apply to perform the moves.")
            return 0
        results = apply_organization(plan, args.destination)
        if args.report:
            write_report(results, args.report)
            print(f"\nReport saved to {args.report}")
        print(f"\nDone: moved {len(results)} file(s).")
        return 0
    except (ValueError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
