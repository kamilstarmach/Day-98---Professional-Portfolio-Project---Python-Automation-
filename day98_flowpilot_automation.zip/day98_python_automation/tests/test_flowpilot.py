import json
import tempfile
import unittest
from pathlib import Path

from main import (
    DEFAULT_RULES, apply_organization, category_for, load_rules,
    plan_organization, unique_destination, write_report,
)


class FlowPilotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "inbox"
        self.destination = self.root / "organized"
        self.source.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def test_category_for_known_and_unknown_extensions(self):
        self.assertEqual(category_for(Path("notes.PDF"), DEFAULT_RULES), "documents")
        self.assertEqual(category_for(Path("mystery.xyz"), DEFAULT_RULES), "other")

    def test_plan_does_not_move_files(self):
        file = self.source / "report.pdf"
        file.write_text("demo")
        plan = plan_organization(self.source, self.destination, DEFAULT_RULES)
        self.assertEqual(len(plan), 1)
        self.assertTrue(file.exists())
        self.assertEqual(plan[0]["category"], "documents")

    def test_apply_organization_moves_files(self):
        file = self.source / "photo.png"
        file.write_text("pixels")
        plan = plan_organization(self.source, self.destination, DEFAULT_RULES)
        result = apply_organization(plan, self.destination)
        self.assertFalse(file.exists())
        self.assertTrue((self.destination / "images" / "photo.png").exists())
        self.assertEqual(result[0]["result"], "moved")

    def test_collision_does_not_overwrite(self):
        file = self.source / "report.pdf"
        file.write_text("new")
        target_dir = self.destination / "documents"
        target_dir.mkdir(parents=True)
        (target_dir / "report.pdf").write_text("old")
        plan = plan_organization(self.source, self.destination, DEFAULT_RULES)
        result = apply_organization(plan, self.destination)
        self.assertEqual((target_dir / "report.pdf").read_text(), "old")
        self.assertTrue((target_dir / "report_1.pdf").exists())
        self.assertEqual(Path(result[0]["destination"]).name, "report_1.pdf")

    def test_source_cannot_equal_or_contain_destination(self):
        with self.assertRaises(ValueError):
            plan_organization(self.source, self.source, DEFAULT_RULES)
        with self.assertRaises(ValueError):
            plan_organization(self.source, self.source / "inside", DEFAULT_RULES)

    def test_load_custom_rules(self):
        rules_file = self.root / "rules.json"
        rules_file.write_text(json.dumps({"ebooks": ["EPUB", ".mobi"]}))
        rules = load_rules(rules_file)
        self.assertEqual(rules["ebooks"], [".epub", ".mobi"])
        self.assertEqual(category_for(Path("book.EPUB"), rules), "ebooks")

    def test_write_report(self):
        report_path = self.root / "reports" / "run.json"
        write_report([{"source": "a.txt", "destination": "documents/a.txt", "category": "documents", "result": "moved"}], report_path)
        report = json.loads(report_path.read_text(encoding="utf-8"))
        self.assertEqual(report["files_processed"], 1)
        self.assertIn("created_at", report)


if __name__ == "__main__":
    unittest.main()
