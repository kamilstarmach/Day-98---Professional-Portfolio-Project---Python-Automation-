# Day 98 — FlowPilot
**100 Days of Code | Professional Portfolio Project — Python Automation**

FlowPilot is a safe-by-default file organization utility. It scans a source folder, classifies files by extension, previews proposed moves, optionally executes the plan, avoids overwriting files, and can write a timestamped JSON report.

## Features
- Preview-first workflow: nothing moves unless `--apply` is supplied
- Categorization for documents, spreadsheets, images, audio, video, archives, and code
- Custom extension rules loaded from JSON
- Collision handling that preserves existing files
- JSON run reports with timestamps and processed-file counts
- Clear CLI errors and standard-library-only implementation
- Unit tests for planning, execution, collision handling, and reports

## Requirements
- Python 3.10+
- No third-party dependencies

## Quick start

Preview organization (safe; no changes are made):

```bash
python main.py organize "./Downloads" "./Downloads_Sorted"
```

Actually move the files:

```bash
python main.py organize "./Downloads" "./Downloads_Sorted" --apply --report "./run-report.json"
```

Show the built-in extension rules:

```bash
python main.py show-rules
```

Use a custom rules file:

```json
{
  "ebooks": [".epub", ".mobi"],
  "design": [".fig", ".sketch", ".psd"]
}
```

Save that as `rules.json`, then run:

```bash
python main.py organize "./Inbox" "./Sorted" --rules rules.json
```

**Safety note:** test with a temporary sample folder first. `--apply` moves files, so verify the source and destination paths before running it.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Project structure

```text
day98_python_automation/
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
└── tests/
    └── test_flowpilot.py
```

## Skills demonstrated
`pathlib`, `shutil`, JSON configuration, command-line interfaces with `argparse`, safe file operations, collision handling, timestamps, and unit testing.
